/*
  Módulo de implementación de `caminos'.

  Laboratorio de Programación 3.
  InCo-FIng-UDELAR
 */

#include "../include/caminos.h"
#include <cstddef>

nat* CantCaminos(Grafo G, nat s)
{
    //Completar...
    
    return NULL;
}
